//+------------------------------------------------------------------+
//| FD Scalper Pro — 1-minute scalping for Gold & US Tech 100 (MT5)   |
//| figurdiscover.com · Mohammad Khamaiseh                            |
//| Signals only on CLOSED candles (no repaint). Not investment advice|
//+------------------------------------------------------------------+
#property copyright "figurdiscover.com"
#property link      "https://figurdiscover.com"
#property version   "1.00"
#property indicator_chart_window
#property indicator_buffers 6
#property indicator_plots   6
#property indicator_label1  "Fast EMA"
#property indicator_type1   DRAW_LINE
#property indicator_color1  clrDeepSkyBlue
#property indicator_width1  1
#property indicator_label2  "Signal EMA"
#property indicator_type2   DRAW_LINE
#property indicator_color2  clrOrange
#property indicator_width2  2
#property indicator_label3  "Base EMA"
#property indicator_type3   DRAW_LINE
#property indicator_color3  clrMediumPurple
#property indicator_width3  2
#property indicator_label4  "VWAP"
#property indicator_type4   DRAW_LINE
#property indicator_color4  clrSilver
#property indicator_style4  STYLE_DOT
#property indicator_label5  "BUY"
#property indicator_type5   DRAW_ARROW
#property indicator_color5  clrLimeGreen
#property indicator_width5  3
#property indicator_label6  "SELL"
#property indicator_type6   DRAW_ARROW
#property indicator_color6  clrRed
#property indicator_width6  3

enum ENUM_FD_ASSET { FD_AUTO=0, FD_GOLD=1, FD_USTECH=2 };
enum ENUM_FD_SESS  { SESS_PRESET=0, SESS_OFF=1 };

input ENUM_FD_ASSET InpAsset     = FD_AUTO;   // Asset preset (Auto / Gold / US Tech 100)
input int           InpFast      = 9;         // Fast EMA
input int           InpMid       = 21;        // Signal EMA
input int           InpSlow      = 50;        // Trend EMA
input int           InpBase      = 200;       // Base EMA
input int           InpRsi       = 7;         // RSI length
input int           InpMinScore  = 5;         // Minimum confluence (3-6)
input bool          InpUseVWAP   = true;      // VWAP filter
input bool          InpUseVol    = true;      // Volume filter (tick volume)
input int           InpCooldown  = 5;         // Minimum bars between signals
input ENUM_FD_SESS  InpSession   = SESS_PRESET; // Trading hours (Gold 07-20 UTC, US Tech 100 09:35-15:55 New York)
input double        InpSlMult    = 0.0;       // Stop = ATR x (0 = preset)
input double        InpTp1R      = 1.0;       // TP1 (reward:risk)
input double        InpTp2R      = 2.0;       // TP2 (reward:risk)
input int           InpMaxBars   = 45;        // Close trade after N bars
input int           InpHistory   = 5000;      // Bars to test
input bool          InpAlerts    = true;      // Pop-up alert on new signal
input bool          InpPush      = false;     // Push notification to MT5 mobile app
input bool          InpLines     = true;      // Draw entry / SL / TP lines

double bFast[], bMid[], bBase[], bVwap[], bBuy[], bSell[];
int hFast, hMid, hSlow, hBase, hRsi, hAtr, hHtf;
bool isGold;
double slM;
datetime lastBar = 0, lastAlerted = 0;
string PFX = "FDSC_";

//+------------------------------------------------------------------+
int OnInit()
{
   SetIndexBuffer(0, bFast, INDICATOR_DATA);
   SetIndexBuffer(1, bMid,  INDICATOR_DATA);
   SetIndexBuffer(2, bBase, INDICATOR_DATA);
   SetIndexBuffer(3, bVwap, INDICATOR_DATA);
   SetIndexBuffer(4, bBuy,  INDICATOR_DATA);
   SetIndexBuffer(5, bSell, INDICATOR_DATA);
   PlotIndexSetInteger(4, PLOT_ARROW, 233);
   PlotIndexSetInteger(5, PLOT_ARROW, 234);
   PlotIndexSetDouble(4, PLOT_EMPTY_VALUE, EMPTY_VALUE);
   PlotIndexSetDouble(5, PLOT_EMPTY_VALUE, EMPTY_VALUE);
   PlotIndexSetInteger(4, PLOT_ARROW_SHIFT, 20);
   PlotIndexSetInteger(5, PLOT_ARROW_SHIFT, -20);

   string s = _Symbol; StringToUpper(s);
   if(InpAsset == FD_GOLD) isGold = true;
   else if(InpAsset == FD_USTECH) isGold = false;
   else isGold = (StringFind(s, "XAU") >= 0 || StringFind(s, "GOLD") >= 0);
   slM = InpSlMult > 0 ? InpSlMult : (isGold ? 1.3 : 1.2);

   hFast = iMA(_Symbol, _Period, InpFast, 0, MODE_EMA, PRICE_CLOSE);
   hMid  = iMA(_Symbol, _Period, InpMid,  0, MODE_EMA, PRICE_CLOSE);
   hSlow = iMA(_Symbol, _Period, InpSlow, 0, MODE_EMA, PRICE_CLOSE);
   hBase = iMA(_Symbol, _Period, InpBase, 0, MODE_EMA, PRICE_CLOSE);
   hRsi  = iRSI(_Symbol, _Period, InpRsi, PRICE_CLOSE);
   hAtr  = iATR(_Symbol, _Period, 14);
   hHtf  = iMA(_Symbol, PERIOD_M5, InpSlow, 0, MODE_EMA, PRICE_CLOSE);
   if(hFast==INVALID_HANDLE || hMid==INVALID_HANDLE || hSlow==INVALID_HANDLE || hBase==INVALID_HANDLE || hRsi==INVALID_HANDLE || hAtr==INVALID_HANDLE || hHtf==INVALID_HANDLE)
      return(INIT_FAILED);
   IndicatorSetString(INDICATOR_SHORTNAME, "FD Scalper (" + (isGold ? "Gold" : "US Tech 100") + ")");
   if(_Period != PERIOD_M1) Print("FD Scalper is designed for the M1 chart.");
   return(INIT_SUCCEEDED);
}
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   ObjectsDeleteAll(0, PFX);
   Comment("");
   IndicatorRelease(hFast); IndicatorRelease(hMid); IndicatorRelease(hSlow); IndicatorRelease(hBase);
   IndicatorRelease(hRsi); IndicatorRelease(hAtr); IndicatorRelease(hHtf);
}
//+------------------------------------------------------------------+
// US daylight saving: 2nd Sunday of March 07:00 UTC to 1st Sunday of November 06:00 UTC
bool UsDst(datetime utc)
{
   MqlDateTime d; TimeToStruct(utc, d);
   int y = d.year;
   MqlDateTime m; m.year=y; m.mon=3; m.day=1; m.hour=7; m.min=0; m.sec=0;
   datetime mar1 = StructToTime(m); MqlDateTime t1; TimeToStruct(mar1, t1);
   int firstSun = (7 - t1.day_of_week) % 7;
   datetime start = mar1 + (firstSun + 7) * 86400;
   MqlDateTime n; n.year=y; n.mon=11; n.day=1; n.hour=6; n.min=0; n.sec=0;
   datetime nov1 = StructToTime(n); MqlDateTime t2; TimeToStruct(nov1, t2);
   datetime end = nov1 + ((7 - t2.day_of_week) % 7) * 86400;
   return (utc >= start && utc < end);
}
bool InSession(datetime serverTime, int srvOffset)
{
   if(InpSession == SESS_OFF) return true;
   datetime utc = serverTime - srvOffset;
   MqlDateTime d;
   if(isGold)
   {
      TimeToStruct(utc, d);
      int m = d.hour * 60 + d.min;
      return (m >= 420 && m < 1200);
   }
   datetime ny = utc - (UsDst(utc) ? 4 : 5) * 3600;
   TimeToStruct(ny, d);
   if(d.day_of_week == 0 || d.day_of_week == 6) return false;
   int m = d.hour * 60 + d.min;
   return (m >= 575 && m < 955);
}
//+------------------------------------------------------------------+
void DrawLine(string name, datetime t, double price, color c, int style, int width)
{
   string n = PFX + name;
   if(ObjectFind(0, n) < 0) ObjectCreate(0, n, OBJ_TREND, 0, t, price, t + 25 * PeriodSeconds(), price);
   ObjectSetInteger(0, n, OBJPROP_TIME, 0, t);
   ObjectSetDouble(0, n, OBJPROP_PRICE, 0, price);
   ObjectSetInteger(0, n, OBJPROP_TIME, 1, t + 25 * PeriodSeconds());
   ObjectSetDouble(0, n, OBJPROP_PRICE, 1, price);
   ObjectSetInteger(0, n, OBJPROP_COLOR, c);
   ObjectSetInteger(0, n, OBJPROP_STYLE, style);
   ObjectSetInteger(0, n, OBJPROP_WIDTH, width);
   ObjectSetInteger(0, n, OBJPROP_RAY_RIGHT, false);
   ObjectSetInteger(0, n, OBJPROP_SELECTABLE, false);
}
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total, const int prev_calculated, const datetime &time[],
                const double &open[], const double &high[], const double &low[], const double &close[],
                const long &tick_volume[], const long &volume[], const int &spread[])
{
   if(rates_total < InpBase + 120) return(0);
   // recalculate once per new bar (signals use closed bars only)
   if(time[rates_total - 1] == lastBar && prev_calculated > 0) return(rates_total);

   if(BarsCalculated(hFast) < rates_total || BarsCalculated(hMid) < rates_total || BarsCalculated(hSlow) < rates_total ||
      BarsCalculated(hBase) < rates_total || BarsCalculated(hRsi) < rates_total || BarsCalculated(hAtr) < rates_total) return(0);

   double eF[], eM[], eS[], eB[], rsi[], atr[];
   if(CopyBuffer(hFast, 0, 0, rates_total, eF) != rates_total) return(0);
   if(CopyBuffer(hMid,  0, 0, rates_total, eM) != rates_total) return(0);
   if(CopyBuffer(hSlow, 0, 0, rates_total, eS) != rates_total) return(0);
   if(CopyBuffer(hBase, 0, 0, rates_total, eB) != rates_total) return(0);
   if(CopyBuffer(hRsi,  0, 0, rates_total, rsi) != rates_total) return(0);
   if(CopyBuffer(hAtr,  0, 0, rates_total, atr) != rates_total) return(0);

   int n5 = Bars(_Symbol, PERIOD_M5);
   if(n5 < InpSlow + 5 || BarsCalculated(hHtf) < n5) return(0);
   double h5[]; ArraySetAsSeries(h5, true);
   int got5 = CopyBuffer(hHtf, 0, 0, n5, h5);
   if(got5 <= 3) return(0);

   lastBar = time[rates_total - 1];
   int srvOffset = (int)(MathRound((double)(TimeTradeServer() - TimeGMT()) / 900.0) * 900);

   int last = rates_total - 2;                  // last CLOSED bar
   int start = (int)MathMax(InpBase + 101, rates_total - InpHistory);

   // lines and VWAP for all bars
   double pv = 0, vv = 0; int curDay = -1;
   for(int i = 0; i < rates_total; i++)
   {
      bFast[i] = eF[i]; bMid[i] = eM[i]; bBase[i] = eB[i];
      bBuy[i] = EMPTY_VALUE; bSell[i] = EMPTY_VALUE;
      int day = (int)((time[i] - srvOffset) / 86400);
      if(day != curDay) { curDay = day; pv = 0; vv = 0; }
      double w = tick_volume[i] > 0 ? (double)tick_volume[i] : 1.0;
      pv += (high[i] + low[i] + close[i]) / 3.0 * w; vv += w;
      bVwap[i] = InpUseVWAP ? pv / vv : EMPTY_VALUE;
   }

   // walk the closed bars: signals + built-in statistics
   int dir = 0, entBar = 0, lastSig = -100000;
   double ent = 0, sl = 0, t1 = 0, t2 = 0, rsk = 0; bool hit1 = false;
   int nTr = 0, nT2 = 0, nLoss = 0; double sumR = 0, gw = 0, gl = 0;
   int lastSigBar = -1; int sL = 0, sS = 0, trendNow = 0;

   for(int i = start; i <= last; i++)
   {
      // manage open trade (if stop and target touch in one bar, count the stop)
      if(dir != 0)
      {
         double r = EMPTY_VALUE;
         if(dir == 1)
         {
            if(low[i] <= sl) { r = hit1 ? 0.5 * InpTp1R : -1.0; if(!hit1) nLoss++; }
            else
            {
               if(!hit1 && high[i] >= t1) { hit1 = true; sl = ent; }
               if(high[i] >= t2) { nT2++; r = 0.5 * InpTp1R + 0.5 * InpTp2R; }
               else if(i - entBar >= InpMaxBars) r = hit1 ? 0.5 * InpTp1R + 0.5 * (close[i] - ent) / rsk : (close[i] - ent) / rsk;
            }
         }
         else
         {
            if(high[i] >= sl) { r = hit1 ? 0.5 * InpTp1R : -1.0; if(!hit1) nLoss++; }
            else
            {
               if(!hit1 && low[i] <= t1) { hit1 = true; sl = ent; }
               if(low[i] <= t2) { nT2++; r = 0.5 * InpTp1R + 0.5 * InpTp2R; }
               else if(i - entBar >= InpMaxBars) r = hit1 ? 0.5 * InpTp1R + 0.5 * (ent - close[i]) / rsk : (ent - close[i]) / rsk;
            }
         }
         if(r != EMPTY_VALUE) { nTr++; sumR += r; if(r > 0) gw += r; else gl -= r; dir = 0; }
      }

      // 5-minute filter from the previous CLOSED M5 bar
      int sh = iBarShift(_Symbol, PERIOD_M5, time[i], false);
      if(sh < 0 || sh + 2 >= got5) continue;
      double hE = h5[sh + 1], hE2 = h5[sh + 2], hC = iClose(_Symbol, PERIOD_M5, sh + 1);
      if(hC <= 0) continue;

      // ATR average (100) and volume average (20)
      double aAvg = 0; for(int k = i - 99; k <= i; k++) aAvg += atr[k]; aAvg /= 100.0;
      double vAvg = 0; for(int k = i - 19; k <= i; k++) vAvg += (double)tick_volume[k]; vAvg /= 20.0;
      bool volOK = !InpUseVol || tick_volume[i] == 0 || tick_volume[i] > vAvg * 1.05;
      bool calm  = atr[i] > aAvg * 0.8 && (high[i] - low[i]) < atr[i] * 3.0;
      double vw = InpUseVWAP ? bVwap[i] : 0;

      sL = (close[i] > eB[i] && eS[i] > eB[i] ? 1 : 0) + (hC > hE && hE >= hE2 ? 1 : 0) + (!InpUseVWAP || close[i] > vw ? 1 : 0)
         + (eF[i] > eM[i] ? 1 : 0) + (rsi[i] > 52 && rsi[i] < 78 ? 1 : 0) + (calm && volOK ? 1 : 0);
      sS = (close[i] < eB[i] && eS[i] < eB[i] ? 1 : 0) + (hC < hE && hE <= hE2 ? 1 : 0) + (!InpUseVWAP || close[i] < vw ? 1 : 0)
         + (eF[i] < eM[i] ? 1 : 0) + (rsi[i] < 48 && rsi[i] > 22 ? 1 : 0) + (calm && volOK ? 1 : 0);
      trendNow = (hC > hE && hE >= hE2) ? 1 : (hC < hE && hE <= hE2) ? -1 : 0;

      bool trigL = (eF[i] > eM[i] && eF[i-1] <= eM[i-1]) || (low[i] <= eM[i] && close[i] > eM[i] && close[i] > open[i] && eF[i] > eM[i] && close[i] > high[i-1]);
      bool trigS = (eF[i] < eM[i] && eF[i-1] >= eM[i-1]) || (high[i] >= eM[i] && close[i] < eM[i] && close[i] < open[i] && eF[i] < eM[i] && close[i] < low[i-1]);
      bool ready = dir == 0 && i - lastSig > InpCooldown && InSession(time[i], srvOffset);
      bool buy  = ready && trigL && sL >= InpMinScore;
      bool sell = ready && !buy && trigS && sS >= InpMinScore;

      if(buy || sell)
      {
         int d = buy ? 1 : -1;
         double lo = low[i], hi = high[i];
         for(int k = i - 4; k <= i; k++) { lo = MathMin(lo, low[k]); hi = MathMax(hi, high[k]); }
         double swing = buy ? lo - atr[i] * 0.1 : hi + atr[i] * 0.1;
         double dist = MathAbs(close[i] - swing);
         dist = MathMax(MathMin(dist, atr[i] * slM * 1.8), atr[i] * slM * 0.7);
         dir = d; ent = close[i]; rsk = dist; sl = ent - d * dist; t1 = ent + d * dist * InpTp1R; t2 = ent + d * dist * InpTp2R;
         hit1 = false; entBar = i; lastSig = i; lastSigBar = i;
         if(buy) bBuy[i] = low[i] - atr[i] * 0.3; else bSell[i] = high[i] + atr[i] * 0.3;
      }
   }

   // lines for the open trade
   ObjectsDeleteAll(0, PFX);
   if(InpLines && dir != 0)
   {
      DrawLine("E",  time[entBar], ent, clrSilver, STYLE_DOT, 1);
      DrawLine("SL", time[entBar], sl, clrRed, STYLE_SOLID, 2);
      DrawLine("T1", time[entBar], t1, clrMediumSeaGreen, STYLE_DASH, 1);
      DrawLine("T2", time[entBar], t2, clrLimeGreen, STYLE_SOLID, 2);
   }

   // alert on a signal that formed on the bar that just closed
   if(lastSigBar == last && time[last] != lastAlerted && prev_calculated > 0)
   {
      lastAlerted = time[last];
      string msg = StringFormat("FD Scalper %s %s @ %s | SL %s | TP1 %s | TP2 %s", dir == 1 ? "BUY" : "SELL", _Symbol,
                                DoubleToString(ent, _Digits), DoubleToString(sl, _Digits), DoubleToString(t1, _Digits), DoubleToString(t2, _Digits));
      if(InpAlerts) Alert(msg);
      if(InpPush) SendNotification(msg);
   }

   double win = nTr > 0 ? 100.0 * (nTr - nLoss) / nTr : 0;
   string pf = gl > 0 ? DoubleToString(gw / gl, 2) : "-";
   Comment(StringFormat("FD Scalper · %s · %s\n5m trend: %s   Buy %d/6 · Sell %d/6\nOpen trade: %s\nTested %d trades on %d bars · reached TP1: %.1f%% · TP2: %.1f%%\nResult: %.1fR · Profit factor: %s  (before spread)\nfigurdiscover.com — not investment advice",
           isGold ? "Gold" : "US Tech 100", InSession(time[last], srvOffset) ? "SESSION ON" : "SESSION OFF",
           trendNow > 0 ? "UP" : trendNow < 0 ? "DOWN" : "FLAT", sL, sS,
           dir == 1 ? "LONG @ " + DoubleToString(ent, _Digits) : dir == -1 ? "SHORT @ " + DoubleToString(ent, _Digits) : "none",
           nTr, last - start + 1, win, nTr > 0 ? 100.0 * nT2 / nTr : 0.0, sumR, pf));
   return(rates_total);
}
//+------------------------------------------------------------------+
